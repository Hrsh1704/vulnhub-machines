1. run the basic nmap scan (network scan)
2. run gobuster for directory bruteforce.
3. after anylyse the result of network scan we knew ftp has anonymous login.
4. extract the file and try to get some info.
5. open ports and looking for intrusting detail.
6. after apllying parameters we got the password of ssh service.
7. login the ssh service and got the user flag.
8. find the ways to get root access. for that upload one exploit was PwtKit. and run it and we got the root connection also.


# FOR THE EXPLOIT I WILL USE OPEN SOURCE SITES.
