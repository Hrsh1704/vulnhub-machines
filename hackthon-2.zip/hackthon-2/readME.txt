1. finding the ip address
2. run the nmap for port scanning
3. run the vulnrability scan for finding any other vulnrability finding if available. and run gobuster for finding hidden directory
4. find the intrusting page and after seeing their source-code we got the username.
5. ftp has an anonymous login allowed so do.
6. we got the our first flag and also got an wordlist.
7. so we are using hydra for do brute force. and we got password also.
8. and we got password also.
9. after got the credential we are try to login on the machine. and after that we are look an file which was bash_history and got 2 cmd which was 'sudo -i and sudo -l'
10.so after running it we git the access of hackthon account and we can use vim cmd using it we try to spwan the root shell for that we run the cmd was "sudo vim -c '!sh' "
11. we got the root connection and also our 2nd flag.
